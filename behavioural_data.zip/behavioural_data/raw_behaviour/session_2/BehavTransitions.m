%%
clear 
close

sub = [301,302,304,305,306,307,308,309,310,311,312,314,315,316,317,318,319,320,323,325,324,326,327,328,329,330,331];

for isub = 1:length(sub)
    disp(['Processing subject ',num2str(sub(isub)),''])

cd /Volumes/'LaCie 1'/fourrooms/behavioural_data/raw_behaviour/session_2/;
s = fileread(['',num2str(sub(isub)),'b.json']);
data = parse_json(s);


numtrial = 0;

for itrial = 8:108
    
    
    if rem(itrial,10) == 0 
        disp(itrial) 
    end
    
    
    if itrial == 24 | itrial == 41 | itrial == 58 | itrial == 75 | itrial == 92 % rest trials, so do nothing
   
    else 
        
        numtrial = numtrial+1;
        
        %Get info about reward context (vertical vs horizontal)
        rew_xdiff = data.allTrialData{itrial}.rewardPositions{1}.x - data.allTrialData{itrial}.rewardPositions{2}.x;%diff in x coordinates between reward locations
        rew_ydiff = data.allTrialData{itrial}.rewardPositions{1}.y - data.allTrialData{itrial}.rewardPositions{2}.y;%diff in y coordinates between reward locations

        if     rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{itrial}.rewardPositions{1}.x == -4
                    rew_context = 1;%vertical context, both rewards on the left
        elseif rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{itrial}.rewardPositions{1}.x == 4
                    rew_context = 2;%vertical context, both rewards on the right
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{itrial}.rewardPositions{1}.y == -4
                    rew_context = 3;%horizontal context, both rewards on the bottom
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{itrial}.rewardPositions{1}.y == 4
                    rew_context = 4;%horizontal context, both rewards on the top
        end

        if rew_context < 3 
            rew_context_binary = 1;%vertical irrespective of side
        elseif rew_context > 2
            rew_context_binary = 2;%horizontal irrespective of side
        end
    
%         context{isub,numtrial} = rew_context_binary;
        context{isub,numtrial} = rew_context;
        
        
        
        a = [];
        for z =  2:length(data.allTrialData{itrial}.timeStepTrackingData)   
            a = [a;str2num(data.allTrialData{itrial}.timeStepTrackingData{z})];
        end
        a =[a(:,3),a(:,5)];%extract only x and y positions
        
        d = [1,1;diff(a)];
        for iframe = 1:length(a)
            if  d(iframe,1) == 0 & d(iframe,2) == 0
                    a(iframe,:) = 99;
            end
        end
        
        duplicate = find(a(:,1) == 99);
        
        a(duplicate,:) = [];
        
        coords{isub,numtrial} = a;
        
        
        if numtrial < 17
            session{isub,numtrial} = 1;
        elseif numtrial > 16 & numtrial < 33
            session{isub,numtrial} = 2;
        elseif numtrial > 32 & numtrial < 49
            session{isub,numtrial} = 3;
        elseif numtrial > 48 & numtrial < 65
            session{isub,numtrial} = 4;
        elseif numtrial > 64 & numtrial < 81
            session{isub,numtrial} = 5;
        elseif numtrial > 80 
            session{isub,numtrial} = 6;
        end
        
        
    end
    
end



end