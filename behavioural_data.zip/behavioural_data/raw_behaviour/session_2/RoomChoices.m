%% read and parse data
clear all
%
sub = [301,302,304,305,306,307,308,309,310,311,312,314,315,316,317,318,319,320,323,324,325,326,327,328,329,330,331];



for isub = 1:length(sub)
    disp(['Processing subject ',num2str(sub(isub)),''])
cd /Volumes/'LaCie 1'/fourrooms/behavioural_data/raw_behaviour/session_2/;
s = fileread(['',num2str(sub(isub)),'b.json']);
data = parse_json(s);
num_trial = 0;
    for i = 8:108
        
        if i == 24 | i == 41 | i == 58 | i == 75 | i == 92 % rest trials
            
            room_choice(i) = NaN;

        else
        
        num_trial =  num_trial+1;
        
        if rem(num_trial,10) == 0
            disp(['Trial',num2str(num_trial),''])
        end
        
        %num_trial = 102;

        %Get info about reward context (vertical vs horizontal)
        rew_xdiff = data.allTrialData{i}.rewardPositions{1}.x - data.allTrialData{i}.rewardPositions{2}.x;%diff in x coordinates between reward locations
        rew_ydiff = data.allTrialData{i}.rewardPositions{1}.y - data.allTrialData{i}.rewardPositions{2}.y;%diff in y coordinates between reward locations

        if     rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{i}.rewardPositions{1}.x == -4
                    rew_context = 1;%vertical context, both rewards on the left
                    rew_rooms = [1,2];
        elseif rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{i}.rewardPositions{1}.x == 4
                    rew_context = 2;%vertical context, both rewards on the right
                    rew_rooms = [3,4];
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{i}.rewardPositions{1}.y == -4
                    rew_context = 3;%horizontal context, both rewards on the bottom
                    rew_rooms = [1,4];
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{i}.rewardPositions{1}.y == 4
                    rew_context = 4;%horizontal context, both rewards on the top
                    rew_rooms = [2,3];
        end

        if rew_context < 3 
            rew_context_binary = 1;%vertical irrespective of side
        elseif rew_context > 2
            rew_context_binary = 2;%horizontal irrespective of side
        end

        %get sequence of states for current trial
        states = data.allTrialData{i}.stateTransitions(2:length(data.allTrialData{i}.stateTransitions));states = str2double(states);
    
        
    %%%%%%%%%%%%%%%%%% 
    %%%Control Mode%%%
    %%%%%%%%%%%%%%%%%%
    
    if strcmp(data.allTrialData{i}.controlStateOrder{1},'Human') == 1
        control_seq = 1;
        cs{i} = 1;
    elseif strcmp(data.allTrialData{i}.controlStateOrder{1},'Computer') == 1
        control_seq = 2;
        cs{i} = 2;
    end
     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Get feedback reward infos%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    feedback1=find(states==8); feedback2=find(states==9); feedback3=find(states==11);feedback=sort([feedback1,feedback2,feedback3]);%get time stamps of all feedback events
    d_fb      = [99,diff(feedback)];%check the difference in time stamps to separate into events
    ev_fb     = length(d_fb(d_fb>1));%get the number of FB events
    pos_ev_fb = find(d_fb>1);%get position of fb onset within vector
    onsets_feedback = feedback(d_fb>1);%Compute their onset (in trial time) 
    
    for iev = 1:ev_fb %compute the duration of each event
        if iev < ev_fb
            dur_feedback(iev) = length(pos_ev_fb(iev):(pos_ev_fb(iev+1)-1));
        elseif iev==ev_fb
            dur_feedback(iev) = length(pos_ev_fb(iev):length(feedback));
        end
    end

    
    %%%%%%%%%%%%%%%%%%%%%
    %%% Get room info %%%
    %%%%%%%%%%%%%%%%%%%%%

    a = [];room = [];
    for z =  2:length(data.allTrialData{i}.timeStepTrackingData)   
    a = [a;str2num(data.allTrialData{i}.timeStepTrackingData{z})];
    end
    a =[a(:,3),a(:,5)];%extract only x and y positions

    for p = 1:length(a)%indicate in which room subject currently is
          if     a(p,1) < 0 & a(p,2)< 0
                    room(p) = 1;
          elseif a(p,1) < 0 & a(p,2)> 0
                    room(p) = 2;
          elseif a(p,1) > 0 & a(p,2) > 0
                    room(p) = 3;
          elseif a(p,1) > 0 & a(p,2) < 0
                    room(p) = 4;
          end
    end
    
    rooms_feedback =[];
    rooms_feedback = room(onsets_feedback);
    
    
  
    rew_positions = find(ismember(rooms_feedback,rew_rooms)==1);
    rew_rooms = rooms_feedback(rew_positions);
    
    if control_seq == 1 & ismember(rooms_feedback(3),rew_rooms) == 1
       room_choice(i) = 1;
       
    elseif control_seq == 1 & ismember(rooms_feedback(3),rew_rooms) == 0
       room_choice(i) = 0;
        
    elseif control_seq == 2 & ismember(rooms_feedback(2),rew_rooms) == 1
        room_choice(i) = 1;
    
    elseif control_seq == 2 & ismember(rooms_feedback(2),rew_rooms) == 0
        room_choice(i) = 0;
        
    end
    
    room_choice_avg(isub) = nanmean(room_choice);


        end
    end
end