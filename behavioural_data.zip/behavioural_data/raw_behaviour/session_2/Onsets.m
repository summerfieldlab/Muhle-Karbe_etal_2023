%% read and parse data
clear all
s = fileread('dataFile_16-10-19_11-25_0206358_302b.json');
data = parse_json(s);

%Get time stamp of first trial (to get time stamps in scanning time for
%other events below)
pulse1 = str2num(data.allTrialData{8}.timeStepTrackingData{2});
if pulse1(2) > 9
        start_scan = str2double(sprintf('%d.%d',pulse1(1),pulse1(2)));
    elseif pulse1(2) < 10
        start_scan = str2double(sprintf('%d.%d%d',pulse1(1),0,pulse1(2)));
end
    

%% get onsets for trials, start cues and feedback signals
onset_trial = [];end_trial=[];cue_onset=[];fb1_onset=[];fb2_onset=[];fb3_onset=[];fb4_onset=[];
for i = 8:108
    if i ~= 24 & i ~= 41 & i ~= 58 & i ~= 75 & i ~= 92 % rest trials
    
    %get trial onset 
    ot = str2num(data.allTrialData{i}.timeStepTrackingData{2});
    if ot(2) > 9
        ot_comb = str2double(sprintf('%d.%d',ot(1),ot(2)));
    elseif ot(2) < 10
        ot_comb = str2double(sprintf('%d.%d%d',ot(1),0,ot(2)));
    end
    onset_trial = [onset_trial;ot_comb];
    
    %get trial offset
    et = str2num(data.allTrialData{i}.timeStepTrackingData{length(data.allTrialData{i}.timeStepTrackingData)});
    if et(2) > 9
        et_comb = str2double(sprintf('%d.%d',et(1),et(2)));
    elseif et(2) < 10
        et_comb = str2double(sprintf('%d.%d%d',et(1),0,et(2)));
    end
    
    end_trial   = [end_trial;et_comb];  
    
    %get onsets for start cue and feedback signals
    for q = 1:6 
        
        if  q == 2 %start cue
            ct = str2num(data.allTrialData{i}.giftWrapStateTransitions{q});
            if ct(2) > 9
                ct_comb = str2double(sprintf('%d.%d',ct(1),ct(2)));
            elseif ct(2) < 10
                ct_comb = str2double(sprintf('%d.%d%d',ct(1),0,ct(2)));
            end
        cue_onset = [cue_onset;ct_comb];%onset of first cue (reward type)
        
        elseif  q == 3 %first feedback
            f1 = str2num(data.allTrialData{i}.giftWrapStateTransitions{q});
            if f1(2) > 9
                f1_comb = str2double(sprintf('%d.%d',f1(1),f1(2)));
            elseif f1(2) < 10
                f1_comb = str2double(sprintf('%d.%d%d',f1(1),0,f1(2)));
            end
        fb1_onset = [fb1_onset;f1_comb];%onset of first feedback(reward type)
        
        
        elseif  q == 4 %second feedback
            f2 = str2num(data.allTrialData{i}.giftWrapStateTransitions{q});
            if f2(2) > 9
                f2_comb = str2double(sprintf('%d.%d',f2(1),f2(2)));
            elseif f2(2) < 10
                f2_comb = str2double(sprintf('%d.%d%d',f2(1),0,f2(2)));
            end
        fb2_onset = [fb2_onset;f2_comb];%onset of second feedback
        
        
        elseif  q == 5 & length(data.allTrialData{i}.giftWrapStateTransitions) > 4 % third feedback when applicable
            f3 = str2num(data.allTrialData{i}.giftWrapStateTransitions{q});
                if f3(2) > 9
                    f3_comb = str2double(sprintf('%d.%d',f3(1),f3(2)));
                elseif f3(2) < 10
                    f3_comb = str2double(sprintf('%d.%d%d',f3(1),0,f3(2)));
                end
            fb3_onset = [fb3_onset;f3_comb];%onset of third feedback if applicable
        
        elseif  q == 5 & length(data.allTrialData{i}.giftWrapStateTransitions) < 5 %NaN third feedback when applicable
            fb3_onset = [fb3_onset;NaN];
        
        elseif  q == 6 & length(data.allTrialData{i}.giftWrapStateTransitions) > 5 % fourth feedback when applicable
            f4 = str2num(data.allTrialData{i}.giftWrapStateTransitions{q});
                if f4(2) > 9
                    f4_comb = str2double(sprintf('%d.%d',f4(1),f4(2)));
                elseif f4(2) < 10
                    f4_comb = str2double(sprintf('%d.%d%d',f4(1),0,f4(2)));
                end
            fb4_onset = [fb4_onset;f4_comb];%onset of fourth feedback if applicable
        
        elseif  q == 6 & length(data.allTrialData{i}.giftWrapStateTransitions) < 6 %NaN fourth feedback when applicable
            fb4_onset = [fb4_onset;NaN];
        

        end
        
    end
    end
end


%% generate variables for trials and runs and combine into single variable
trial = [1:96]';runs = [ones(16,1);ones(16,1)*2;ones(16,1)*3;ones(16,1)*4;ones(16,1)*5;ones(16,1)*6];
blocktrial = [repmat([1:16],1,6)]';
onsets = [trial,runs,blocktrial,onset_trial,fb1_onset,fb2_onset,fb3_onset,fb4_onset,end_trial];

%% get scanner trigger times
t = (cell2mat(data.scannerTriggerTimes));
%find gaps
t_gap = find(diff(t)>2.5);
t_gap_proc = [t_gap(1:4),t_gap(6:8)];

%get number of volumes per run
for i = 1:7
    if i == 1
        run_vols(i) = t_gap_proc(i)-1;
    elseif i > 1 & i < 5
        run_vols(i) = (t_gap_proc(i)-1)-t_gap_proc(i-1);
    elseif i > 1 & i > 5
        run_vols(i) = (t_gap_proc(i)-1)-t_gap_proc(i-1);
    end
end
run_vols(run_vols==0)=[];

%get time stamp of each run's first pulse
tr = [t_gap_proc(1:4),t_gap_proc(6:7)];run_tstart = [0];runtime=[];%zeros(16,1)];
for i = 1:6
    run_tstart = [run_tstart;cell2mat(data.scannerTriggerTimes(tr(i)+1))];
    runtime = [runtime;repmat(run_tstart(i),16,1)];
end
    
fb1_runtime = fb1_onset - runtime;
fb2_runtime = fb2_onset - runtime;
fb3_runtime = fb3_onset - runtime;
fb4_runtime = fb4_onset - runtime;
onset_trial_runtime = onset_trial - runtime;

fb_runtime = [trial,runs,blocktrial,onset_trial_runtime,fb1_runtime,fb2_runtime,fb3_runtime,fb4_runtime]


%%

%Get onsets and durations of events of interest
onset_iti=[];dur_iti=[];onset_start=[];dur_start=[];onset_goal=[];dur_goal=[];onset_delay=[];dur_delay=[];onset_freeze=[];dur_freeze=[];
onset_fb_no_rew =[];dur_fb_no_rew =[];onset_fb_rew1 =[];dur_fb_rew1 =[];onset_fb_rew2 =[];dur_fb_rew2 =[];onset_fb_both_rew =[];dur_fb_both_rew =[];
onset_move1=[];dur_move1=[];onset_move2=[];dur_move2=[];
num_trial = 0;
for i = 8:108
    
    if i ~= 24 & i ~= 41 & i ~= 58 & i ~= 75 & i ~= 92 % rest trials
    
    num_trial =  num_trial+1;
    
    states = data.allTrialData{i}.stateTransitions(2:length(data.allTrialData{i}.stateTransitions));states = str2double(states);
    %get ITI infos
    onset_iti = [onset_iti;min(find(states==2))*0.04+onset_trial_runtime(num_trial)];
    dur_iti = [dur_iti;length(find(states==2))*0.04];
    
    %get start trial infos
    onset_start = [onset_start;min(find(states==3))*0.04+onset_trial_runtime(num_trial)];
    dur_start = [dur_start;length(find(states==3))*0.04];
    
    %get goal cue infos
    onset_goal = [onset_goal;min(find(states==4))*0.04+onset_trial_runtime(num_trial)];
    dur_goal = [dur_goal;length(find(states==4))*0.04];
    
    %get delay infos
    onset_delay = [onset_delay;min(find(states==5))*0.04+onset_trial_runtime(num_trial)];
    dur_delay = [dur_delay;length(find(states==5))*0.04];

    
    %get hallway freeze infos
    freeze = find(states==20);diff_freeze = [1,find(diff(freeze)>1)+1];%get all freeze states and calculate when sequences start
    
    for q = 1:length(diff_freeze)%Loop over each sequence 
        
        onset_freeze = [onset_freeze,freeze(diff_freeze(q))*0.04 + onset_trial_runtime(num_trial)];
        
        if q < length(diff_freeze)
            dur_freeze = [dur_freeze,(freeze(diff_freeze(q+1)-1) - (freeze(diff_freeze(q))))*0.04];
        elseif q == length(diff_freeze)
            dur_freeze = [dur_freeze,(freeze(length(freeze)) - (freeze(diff_freeze(q))))*0.04];
        end
            
    end
     
    
    %get move1 infos
    move1 = (find(states> 5 & states < 8));
    move1_on = move1((diff([0,move1])>1));
    move1_dur =[];
    
    for q = 1:length(move1_on)
        if q < length(move1_on)
            move1_dur = [move1_dur,length(move1(move1>=move1_on(q)&move1<(move1_on(q+1))))];
        
        elseif q == length(move1_on)
            move1_dur = [move1_dur,length(move1(move1>=move1_on(q)))];
        end
    end
    onset_move1 = [onset_move1,move1_on*0.04+onset_trial_runtime(num_trial)];
    dur_move1 = [dur_move1,move1_dur*0.04];
    
    %get move2 infos
    move2 = (find(states == 10));
    move2_on = move2((diff([0,move2])>1));
    move2_dur =[];
    
    %get onsets and durations of move 2 events 
    for q = 1:length(move2_on)
        if q < length(move2_on)
            move2_dur = [move2_dur,length(move2(move2>=move2_on(q)&move2<(move2_on(q+1))))];
        elseif q == length(move2_on)
            move2_dur = [move2_dur,length(move2(move2>=move2_on(q)))];
        end
    end
    
    %Transform from time stamps into trial time
    onset_move2 = [onset_move2,move2_on*0.04+onset_trial_runtime(num_trial)];
    dur_move2 = [dur_move2,move2_dur*0.04];
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Get feedback reward infos%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    feedback1=find(states==8); feedback2=find(states==9); feedback3=find(states==11);feedback=sort([feedback1,feedback2,feedback3]);%get time stamps of all feedback events
    onsets_feedback = feedback((diff([0,feedback])>1));%onsets of all feedback events (in trial time) might not be needed
    fb_last = [feedback(find(diff(feedback)>1)),feedback(length(feedback))];%get time stamp of last state in each fb_sequence
    
    
    %write onsets of each feedbacktype in corresponding event list
    for q = 1:length(fb_last)
        if fb_last(q) < length(states) & states((fb_last(q))+1)==7 %no reward found, zero so far
            onset_fb_no_rew = [onset_fb_no_rew,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            dur_fb_no_rew   = [dur_fb_no_rew,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
            
        elseif fb_last(q) < length(states) & states((fb_last(q))+1)==10 & states((onsets_feedback(q))-1) == 10
            onset_fb_no_rew = [onset_fb_no_rew,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            dur_fb_no_rew   = [dur_fb_no_rew,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
            
        elseif fb_last(q) < length(states) & states((fb_last(q))+1)==10 & states((onsets_feedback(q))-1) == 7
            onset_fb_rew1 = [onset_fb_rew1,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            onset_fb_both_rew = [onset_fb_both_rew,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            dur_fb_rew1   = [dur_fb_rew1,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
            dur_fb_both_rew   = [dur_fb_both_rew,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
            
        elseif states(fb_last(q)) == 11%second reward found
            onset_fb_rew2 = [onset_fb_rew2,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            onset_fb_both_rew = [onset_fb_both_rew,onsets_feedback(q)*0.04+onset_trial_runtime(num_trial)];
            dur_fb_rew2   = [dur_fb_rew2,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
            dur_fb_both_rew   = [dur_fb_both_rew,fb_last(q)*0.04 - onsets_feedback(q)*0.04];
        end
    end 
    end
end

%get number of events for move and feedback events for each run
dm1 = [1,diff(onset_move1)];num_dm1 = [1,find((dm1<0))];
dm2 = [1,diff(onset_move2)];num_dm2 = [1,find((dm2<0))];
fb_nr = [1,diff(onset_fb_no_rew)];num_fb_nr = [1,find((fb_nr<0))];
fb_br = [1,diff(onset_fb_both_rew)];num_fb_br = [1,find((fb_br<0))];
fb_r1 = [1,diff(onset_fb_rew1)];num_fb_r1 = [1,find((fb_r1<0))];
fb_r2 = [1,diff(onset_fb_rew2)];num_fb_r2 = [1,find((fb_r2<0))];
fr = [1,diff(onset_freeze)];num_fr = [1,find((fr<0))];



%% Print onset data in file
clear onsets;
fid1 = fopen(['/Users/paulmk/Desktop/test/sub-302/onsets/Sub302_onsets.mat'],'a');
for i = 1%:6

names = {'iti','start','goal','delay','move1','move2','feedback_no_rew','feedback_rew','freeze'};

onsets{1} = (onset_iti(runs==i) - start_scan)';
onsets{2} = (onset_start(runs==i) - start_scan)';
onsets{3} = (onset_goal(runs==i) - start_scan)';
onsets{4} = (onset_delay(runs==i) - start_scan)';

if i < 6
    onsets{5} = (onset_move1(num_dm1(i):(num_dm1(i+1)-1)) - start_scan);
    onsets{6} = (onset_move2(num_dm2(i):(num_dm2(i+1)-1)) - start_scan);
    onsets{7} = (onset_fb_no_rew(num_fb_nr(i):(num_fb_nr(i+1)-1)) - start_scan);
    onsets{8} = (onset_fb_both_rew(num_fb_br(i):(num_fb_br(i+1)-1)) - start_scan);
    onsets{9} = (onset_freeze(num_fr(i):(num_fr(i+1)-1)) - start_scan);
elseif i == 6
    onsets{5} = (onset_move1(num_dm1(i):length(dm1)) - start_scan);
    onsets{6} = (onset_move2(num_dm2(i):length(dm2)) - start_scan);
    onsets{7} = (onset_fb_no_rew(num_fb_nr(i):length(fb_nr)) - start_scan);
    onsets{8} = (onset_fb_both_rew(num_fb_br(i):length(fb_br)) - start_scan);
    onsets{9} = (onset_freeze(num_fr(i):length(fr)) - start_scan);
end

durations{1} = dur_iti(runs==i)';
durations{2} = dur_start(runs==i)';
durations{3} = dur_goal(runs==i)';
durations{4} = dur_delay(runs==i)';

if i < 6
    durations{5} = dur_move1(num_dm1(i):(num_dm1(i+1)-1));
    durations{6} = dur_move1(num_dm2(i):(num_dm2(i+1)-1));
    durations{7} = dur_fb_no_rew(num_fb_nr(i):(num_fb_nr(i+1)-1));
    durations{8} = dur_fb_both_rew(num_fb_br(i):(num_fb_br(i+1)-1));
    durations{9} = dur_freeze(num_fr(i):(num_fr(i+1)-1));
elseif i ==6
    durations{5} = dur_move1(num_dm1(i):length(dm1));
    durations{6} = dur_move1(num_dm2(i):length(dm2));
    durations{7} = dur_fb_no_rew(num_fb_nr(i):length(fb_nr));
    durations{8} = dur_fb_both_rew(num_fb_br(i):length(fb_br));
    durations{9} = dur_freeze(num_fr(i):length(fr));
end

% change directory to respective run and save conditions file
save('Sub_302_conditions','names','onsets','durations')

end


% %% Print duration data in file
% 
% fid2 = fopen(['/Users/paulmk/Desktop/test/sub-302/onsets/Sub302_durations.m'],'a');
% for i = 1%:6
%     
% fprintf(fid2,'iti_%d\t',i); 
% fprintf(fid2,'%f\t',dur_iti(runs==i));
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'start_%d\t',i);
% fprintf(fid2,'%f\t',dur_start(runs==i));
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'goal_%d\t',i); 
% fprintf(fid2,'%f\t',dur_goal(runs==i));
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'delay_%d\t',i); 
% fprintf(fid2,'%f\t',dur_delay(runs==i));
% fprintf(fid2,'\n');
% 
% 
% fprintf(fid2,'move1_%d\t',i); 
% if i < 6
%     fprintf(fid2,'%f\t',dur_move1(num_dm1(i):(num_dm1(i+1)-1)));
% elseif i == 6
%     fprintf(fid2,'%f\t',dur_move1(num_dm1(i):(length(dm1))));
% end
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'move2_%d\t',i); 
% if i < 6
%     fprintf(fid2,'%f\t',dur_move2(num_dm2(i):(num_dm2(i+1)-1)));
% elseif i == 6
%     fprintf(fid2,'%f\t',dur_move2(num_dm2(i):(length(dm2))));
% end
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'fb_rew_%d\t',i); 
% if i < 6
%     fprintf(fid2,'%f\t',dur_fb_both_rew(num_fb_br(i):(num_fb_br(i+1)-1)));
% elseif i == 6
%     fprintf(fid2,'%f\t',dur_fb_both_rew(num_fb_br(i):(length(fb_br))));
% end
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'fb_no_rew_%d\t',i); 
% if i < 6
%     fprintf(fid2,'%f\t',dur_fb_no_rew(num_fb_nr(i):(num_fb_nr(i+1)-1)));
% elseif i == 6
%     fprintf(fid2,'%f\t',dur_fb_no_rew(num_fb_nr(i):(length(fb_nr))));
% end
% fprintf(fid2,'\n');
% 
% fprintf(fid2,'freeze_%d\t',i); 
% if i < 6
%     fprintf(fid2,'%f\t',dur_freeze(num_fr(i):(num_fr(i+1)-1)));
% elseif i == 6
%     fprintf(fid2,'%f\t',dur_freeze(num_fr(i):(length(fr))));
% end
% fprintf(fid2,'\n');
% 
% % fprintf(fid2,'move1_%d\t',i); 
% % fprintf(fid2,'%f\t',dur_move1(runs==i));
% % fprintf(fid2,'\n');
% % 
% % fprintf(fid2,'move2_%d\t',i); 
% % fprintf(fid2,'%f\t',dur_move2(runs==i));
% % fprintf(fid2,'\n');
% % 
% % fprintf(fid2,'fb_rew_%d\t',i); 
% % fprintf(fid2,'%f\t',dur_fb_both_rew(runs==i));
% % fprintf(fid2,'\n');
% % 
% % fprintf(fid2,'fb_no_rew_%d\t',i); 
% % fprintf(fid2,'%f\t',dur_fb_no_rew(runs==i));
% % fprintf(fid2,'\n');
% % 
% % fprintf(fid2,'freeze_%d\t',i); 
% % fprintf(fid2,'%f\t',dur_freeze(runs==i));
% % fprintf(fid2,'\n');
% 
% end