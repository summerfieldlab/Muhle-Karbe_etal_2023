%%
clear

subs = [301,302,304,305,306,307,308,309,310,311,312,314,315,316,317,318,319,320,323,324,325,326,327,328,329,330,331];
    
for isub = 1:length(subs)
    s = fileread(['',num2str(subs(isub)),'b.json']);
    data = parse_json(s);

    for itrial = 8:108
        score{isub,itrial} = data.allTrialData{itrial}.trialScore;
    end
end