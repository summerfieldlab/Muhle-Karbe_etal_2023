%% read and parse data
clear all
%
sub = [301,302,304,305,306,307,308,309,310,311,312,314,315,316,317,318,319,320,323,324,325,326,327,328,329,330,331];



for isub = 1:length(sub)
    disp(sub(isub))
%cd /Volumes/'LaCie 1'/fourrooms/behavioural_data/raw_behaviour/session_2/;
s = fileread(['',num2str(sub(isub)),'b.json']);
data = parse_json(s);
num_trial = 0;
    for i = 8:108
        
        if i == 24 | i == 41 | i == 58 | i == 75 | i == 92 % rest trials

        else
        
        num_trial =  num_trial+1;
        %num_trial = 102;

        %Get info about reward context (vertical vs horizontal)
        rew_xdiff = data.allTrialData{i}.rewardPositions{1}.x - data.allTrialData{i}.rewardPositions{2}.x;%diff in x coordinates between reward locations
        rew_ydiff = data.allTrialData{i}.rewardPositions{1}.y - data.allTrialData{i}.rewardPositions{2}.y;%diff in y coordinates between reward locations

        if     rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{i}.rewardPositions{1}.x == -4
                    rew_context = 1;%vertical context, both rewards on the left
                    rew_rooms = [1,2];
        elseif rew_xdiff == 0 & rew_ydiff ~= 0 & data.allTrialData{i}.rewardPositions{1}.x == 4
                    rew_context = 2;%vertical context, both rewards on the right
                    rew_rooms = [3,4];
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{i}.rewardPositions{1}.y == -4
                    rew_context = 3;%horizontal context, both rewards on the bottom
                    rew_rooms = [1,4];
        elseif rew_xdiff ~= 0 & rew_ydiff == 0 & data.allTrialData{i}.rewardPositions{1}.y == 4
                    rew_context = 4;%horizontal context, both rewards on the top
                    rew_rooms = [2,3];
        end

        if rew_context < 3 
            rew_context_binary = 1;%vertical irrespective of side
        elseif rew_context > 2
            rew_context_binary = 2;%horizontal irrespective of side
        end

        %get sequence of states for current trial
        states = data.allTrialData{i}.stateTransitions(2:length(data.allTrialData{i}.stateTransitions));states = str2double(states);


        %%%%%%%%%%%%%%%%%%%%%
        %%% Get room info %%%
        %%%%%%%%%%%%%%%%%%%%%

        a = [];room = [];
        for z =  2:length(data.allTrialData{i}.timeStepTrackingData)   
            a = [a;str2num(data.allTrialData{i}.timeStepTrackingData{z})];
        end
        a =[a(:,3),a(:,5)];%extract only x and y positions

        for p = 1:length(a)%indicate in which room subject currently is
              if     a(p,1) < 0 & a(p,2)< 0
                        room(p) = 1;
              elseif a(p,1) < 0 & a(p,2)> 0
                        room(p) = 2;
              elseif a(p,1) > 0 & a(p,2) > 0
                        room(p) = 3;
              elseif a(p,1) > 0 & a(p,2) < 0
                        room(p) = 4;
              end
        end

    %     if sub == 320 & i == 60
    %         room(764:844) = 3;
    %     end

        r1 = find((room==1));
        r2 = find((room==2));
        r3 = find((room==3));
        r4 = find((room==4));
        % Find onsets of each event
        if      length(r1) > 0 & min(r1) > 1 
                    onset_r1 = r1((diff([0,r1])>1)); 
        elseif length(r1) > 0 & min(r1) == 1 
                    onset_r1 = r1(1);
        elseif length(r1) == 0
                    onset_r1 = [];
        end

        if      length(r2) > 0 & min(r2) > 1 
                    onset_r2 = r2((diff([0,r2])>1));
        elseif length(r2) > 0 & min(r2) == 1 
                    onset_r2 = r2(1);
        elseif length(r2) == 0
                    onset_r2 = [];
        end

        if      length(r3) > 0 & min(r3) > 1 
                    onset_r3 = r3((diff([0,r3])>1));
        elseif length(r3) > 0 & min(r3) == 1 
                    onset_r3 = r3(1);
        elseif length(r3) == 0
                    onset_r3 = [];
        end

        if      length(r4) > 0 & min(r4) > 1 
                    onset_r4 = r4((diff([0,r4])>1)); 
        elseif length(r4) > 0 & min(r4) == 1 
                    onset_r4 = r4(1);
        elseif length(r4) == 0
                    onset_r4 = [];
        end

    %     onset_r1 = r1((diff([0,r1])>1));
    %     onset_r2 = r2((diff([0,r2])>1));
    %     onset_r3 = r3((diff([0,r3])>1));
    %     onset_r4 = r4((diff([0,r4])>1));
    %     
        onset_r_all = sort([onset_r1,onset_r2,onset_r3,onset_r4]);
        rooms_all   = room(onset_r_all);

        room_first{isub,num_trial}  = rooms_all(1);
        room_second{isub,num_trial} = rooms_all(2);
        context{isub,num_trial}     = rew_context_binary;
        
        if ismember(rooms_all(1),rew_rooms) == 1
             rew_first{isub,num_trial} = 1;
        else rew_first{isub,num_trial} = 0;
        end
        
        if ismember(rooms_all(2),rew_rooms) == 1
             rew_second{isub,num_trial} = 1;
        else rew_second{isub,num_trial} = 0;
        end
        


        %Compute if transition frequencies from first to second room differ based on context

        % Vertical Context
        if rew_context_binary == 1 & rooms_all(2) == 1 & rooms_all(1) == 2
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 1 & rooms_all(2) == 1 & rooms_all(1) == 4
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 1 & rooms_all(2) == 2 & rooms_all(1) == 1
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 1 & rooms_all(2) == 2 & rooms_all(1) == 3
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 1 & rooms_all(2) == 3 & rooms_all(1) == 4
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 1 & rooms_all(2) == 3 & rooms_all(1) == 2
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 1 & rooms_all(2) == 4 & rooms_all(1) == 3
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 1 & rooms_all(2) == 4 & rooms_all(1) == 1
            room_transition{isub,num_trial} = 1;%between context transition

        % Horizontal Context    
        elseif rew_context_binary == 2 & rooms_all(2) == 1 & rooms_all(1) == 4
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 2 & rooms_all(2) == 1 & rooms_all(1) == 2
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 2 & rooms_all(2) == 2 & rooms_all(1) == 3
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 2 & rooms_all(2) == 2 & rooms_all(1) == 1
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 2 & rooms_all(2) == 3 & rooms_all(1) == 2
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 2 & rooms_all(2) == 3 & rooms_all(1) == 4
            room_transition{isub,num_trial} = 1;%between context transition

        elseif rew_context_binary == 2 & rooms_all(2) == 4 & rooms_all(1) == 1
            room_transition{isub,num_trial} = 0;%within context transition
        elseif rew_context_binary == 2 & rooms_all(2) == 4 & rooms_all(1) == 3
            room_transition{isub,num_trial} = 1;%between context transition
        end




        end
    end
end